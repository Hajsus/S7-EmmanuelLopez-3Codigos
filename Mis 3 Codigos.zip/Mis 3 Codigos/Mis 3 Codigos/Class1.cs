﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mis_3_Codigos
{
    public class Codigo1
    {

        public void Circulo()
        {

            Console.WriteLine("\nElegiste Circulo");
            Console.WriteLine("Porfavor indica el Radio del circulo: ");

            double Radio = double.Parse(Console.ReadLine());

            // Pi. y Elevacion.

            double pi = Math.PI;

            double potencia = Math.Pow(Radio, 2);

            // Codigo

            Console.WriteLine("\nSu Area es de: " + pi * potencia);

        }

        public void Cuadrado()
        {

            Console.WriteLine("\nElegiste Cuadrado");
            Console.WriteLine("Porfavor indica la medida del Lado del Cuadrado: ");

            double Lado = double.Parse(Console.ReadLine());

            // Codigo

            Console.WriteLine("\nSu Area es de: " + Lado * Lado);

        }

        public void Triangulo()
        {

            Console.WriteLine("\nElegiste Triangulo");
            Console.WriteLine("Porfavor determina la Base y Altura del triangulo: ");

            double Base = double.Parse(Console.ReadLine());
            double Altura = double.Parse(Console.ReadLine());

            // Codigo

            Console.WriteLine("\nSu Area es de: " + ((Base * Altura) / 2));

        }

    }

    public class Codigo2
    {

        public void MPro()
        {

            int
            _Precio1 = 100,
            _Precio2 = 80,
            _Precio3 = 60,
            _Precio4 = 50,

            PMenor = 20,
            PMayor = 40,

            recarga1 = 5,
            recarga2 = 10;



        }

    }

    public class Codigo3
    {

        public void LaDivi()
        {

            Console.WriteLine("\nIngresa el numero que desea dividir: ");
            double Nume = double.Parse(Console.ReadLine());

            for (int i = 1; i < 11; i++)
            {

                Console.WriteLine("\n" + (Nume + "/" + i + "= ") + (Nume / i));

            }

        }

    }

}
