﻿using Mis_3_Codigos;

// ****** MIS TRES CODIGOS ******

// INTRO

bool Reiniciar = false;

Console.WriteLine("Bienvenido a mis 3 codigos");

try
{

    do 
    {   

        Console.WriteLine("\nElige el que deseas hacer.\n");

        Console.WriteLine("1. Codigo 1");
        Console.WriteLine("2. Codigo 2");
        Console.WriteLine("3. Codigo 3");
        Console.WriteLine("4. Cerrar el Programa");

        Console.WriteLine("\nElige el numero del codigo deseado. ");

        double Elige = double.Parse(Console.ReadLine());

        switch (Elige)
        {


            case 1:
                {

                    Console.WriteLine("\nElegiste Codigo 1");

                    Codigo1 oCodigo1 = new Codigo1();

                    // Primer Codigo

                    bool Reiniciar1 = false;

                    do
                    {

                        Console.WriteLine("\n*** Sacar Area ***");
                        Console.WriteLine("\nElige cual deseas.\n");

                        Console.WriteLine("1. Circulo");
                        Console.WriteLine("2. Cuadrado");
                        Console.WriteLine("3. Triangulo");

                        Console.WriteLine("\nElige el numero del cual deseas sacar area.");

                        double Elige1 = double.Parse(Console.ReadLine());

                        switch (Elige1)
                        {


                            case 1:
                                {

                                    oCodigo1.Circulo();
                                    Console.ReadKey();

                                }
                                break;

                            case 2:
                                {

                                    oCodigo1.Cuadrado();
                                    Console.ReadKey();

                                }
                                break;

                            case 3:
                                {

                                    oCodigo1.Triangulo();
                                    Console.ReadKey();

                                }
                                break;

                            default:
                                {

                                    Console.WriteLine("Elige una de las opciones dadas.");
                                    Reiniciar1 = true;

                                }
                                break;

                        }

                    }
                    while (Reiniciar1 == true);

                }
                break;

            case 2:
                {

                    // Segundo Codigo
                    Console.WriteLine("\nElegiste Codigo 2\n");

                    Codigo2 oCodigo2 = new Codigo2();

                    oCodigo2.MPro();

                }
                break;

            case 3:
                {

                    // Tercer codigo
                    Console.WriteLine("\nElegiste Codigo 3\n");

                    Console.WriteLine("*** Dividir entre 10 ***");

                    Codigo3 oCodigo3 = new Codigo3();

                    oCodigo3.LaDivi();

                }
                break;

            case 4:
                {

                    Reiniciar = false;

                    // Tercer codigo
                    Console.WriteLine("\nAdios OwO");
                    Console.ReadKey();

                }
                break;

            default:
                {

                    Reiniciar = true;
                    Console.WriteLine("\nError de eleccion.");
                    Console.WriteLine("PorFavor ...");

                }
                break;
        }

    } while (Reiniciar == true);

}
catch
{

    Console.WriteLine("ERROR");

}

